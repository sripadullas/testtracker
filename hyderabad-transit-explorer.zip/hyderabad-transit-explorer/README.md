# Hyderabad Transit Explorer

## Run
```bash
npm install
npm run dev
```

## Upload GTFS
Upload an Excel workbook containing sheets named:
- routes.txt
- stops.txt
- trips.txt
- stop_times.txt
- feed_info.txt
